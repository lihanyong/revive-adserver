<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$conf = $GLOBALS['_MAX']['CONF'];

$words =  array(
    'iFrame Tag' => 'Código iFrame',
    'Allow iFrame Tags' => 'Permitir código iFrame',
    'Placement Comment' => 'Colocar esta parte del código justo encima de la etiqueta </body>',
);

?>
